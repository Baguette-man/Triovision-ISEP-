package com.example.triovisioniseprtp.classes;


public class Player {
    Integer id;
    String name;

    public Player(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public Player() {
    }
}
